export class Users{
    username:string;
    pass:string;
    email:string
}

var tmpGlobalUsers:Array<Users> = [];
export {tmpGlobalUsers};